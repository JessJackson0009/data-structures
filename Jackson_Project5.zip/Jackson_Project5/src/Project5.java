import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * class to hold the main method and present user with options and take in input. 
 * @author jessicajackson
 * @version Dec42022
 */
public class Project5 {
	/**
	 * main method used to read a user defined file and create country objects from it. Inserts country name
	 * population and cases to a hash table as well.
	 * @param args
	 */
	public static void main(String[] args) {
		
		HashTable hash = new HashTable(293);
		
		Scanner fileName = new Scanner(System.in);
		System.out.println("Enter File Name");
		String file = fileName.nextLine();
		//fileName.close();
		
		
		Scanner input = null;
		try {
			input = new Scanner(new File(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(1);
		}
		input.useDelimiter(",|\n");
		input.nextLine();
		int i = 0;
		while(input.hasNext()) {
			String n = input.next();
			String c = input.next();
			long p = input.nextLong();
			double G = input.nextDouble();
			long ca = input.nextLong();
			double d = input.nextDouble();
			String a = input.next();
			double a1 = Double.parseDouble(a);
			Country country = new Country(n, c, p, G, ca, d, a1);
			hash.insert(country.getName(), country.getPop(), country.getCases());
		}
	Menu(hash);
	}
		
	/**
	 * used to create menu and move through menu options until prompted to quit program
	 * @param h HashTable created in main that can be inserted to, deleted from, searched through, and determine the 
	 * number of empty and collided cells.
	 */
	static void Menu(HashTable h) throws InputMismatchException {
		
		int in;
		Scanner scn = new Scanner(System.in);
		System.out.print("1. Print hash table\n2. Delete a country of a given name\n3. Insert a country of a given name\n4. Search and print a country and its case rate"
				+ " for a given name\n5. Print numbers of empty cells and collided cells\n6. Exit\n\n Enter Choice: ");
		
		in = scn.nextInt();
		while(in != 6) {
			if(in > 6 || in < 1 || Character.isDigit(in) == true) {
				System.out.println("\n\ninvalid try again\n\n");
				}
			if(in == 1) {
				h.display();
				System.out.println("");
			}
			if(in == 2) {
				String input;
				Scanner temp2 = new Scanner(System.in);
				System.out.println("What country would you like to delete?");
				input = temp2.nextLine();
				h.delete(input);
			}
			if(in == 3) {
				String input3;
				long pop;
				long cas;
				Scanner temp3 = new Scanner(System.in);
				System.out.println("Name of country to insert:");
				input3 = temp3.nextLine();
				System.out.println("Population of country to insert:");
				pop = temp3.nextLong();
				System.out.println("Number of covid cases for country:");
				cas = temp3.nextLong();
				h.insert(input3, pop, cas);
			}
			if(in == 4) {
				String input4;
				Scanner temp4 = new Scanner(System.in);
				System.out.println("What country would you like to find?");
				input4 = temp4.nextLine();
				h.find(input4);
				
			}
			if(in == 5) {
				
				h.printEmptyAndCollidedCells();
				
			}
			
				
			System.out.print("1. Print hash table\n2. Delete a country of a given name\n3. Insert a country of a given name\n4. Search and print a country and its case rate "
					+ "for a given name\n5. Print numbers of empty cells and collided cells\n6. Exit\n\n Enter Choice: ");
			in = scn.nextInt();
		}
}
		
}
