/**
 * class that creates a hash table using seperate chaining using a singly linked list. which can be inserted to, deleted from
 * searched through, and find the collided and empty cells.
 * @author jessicajackson
 * @version 4DEc2022
 */
public class HashTable {
	
	private LinkList[] hashArr;
	private int arraySize;
	
	/**
	 * constructor for an empty hash table using an array
	 * @param size size of hash array
	 */
	public HashTable(int size) {
	arraySize = size;
	hashArr = new LinkList[arraySize]; 
	
	for(int j=0; j<arraySize; j++) { 
		hashArr[j] = new LinkList();
		}; 
	}
	
	/**
	 * finds the hash value for the user defined country name 
	 * @param country defined name of country
	 * @return returns the hashed value of the entire string
	 */
	public int hashFunc(String country) {
		int total = 0;
		for (int i = 0; i <= country.length()-1; i++) {

            total = total + (int)country.charAt(i);
        }
		total = total % 293;
        return total;
	}
	
	/**
	 * inserts into the hash table based of hash value.
	 * @param name name of country
	 * @param population pop of country
	 * @param cases cases per country
	 */
	public void insert(String name, long population, long cases) {
		
	String key = name;
	int hashVal = hashFunc(key); 
	hashArr[hashVal].insert(name, population, cases);
	}
	
	/**
	 * displays the hash table from first to last index
	 */
	public void display() {
		for(int i=0; i<arraySize; i++) {
			if(hashArr[i].isEmpty()) {
				System.out.println(i + ". Empty");
				continue;
			}
			System.out.print(i + ". ");
			hashArr[i].print();
		}
	}
	
	/**
	 * find the country that was defined by the user and prints its name, index, and caserate.
	 * @param country country named defined by user.
	 * @return return the hash value where the country was found.
	 */
	public int find(String country) {
		int hash = hashFunc(country);
		Node node = hashArr[hash].find(country);
		return hash;
	}

	/**
	 * deletes a user defined country
	 * @param country country name 
	 */
	public void delete(String country) {
		int hash = hashFunc(country);
		hashArr[hash].delete(country);
	}
	
	/**
	 * checks to see at each index if a cell is empty or has more than one country in it. and prints
	 * the amount of both
	 */
	public void printEmptyAndCollidedCells() {
		int emptyCount = 0;
		int collideCount = 0;
		for(int i=0; i<arraySize; i++) {
			if(hashArr[i].isEmpty()) {
				emptyCount++;
			}
			if(hashArr[i].isCollided()) {
				collideCount++;
			}
		}
		System.out.println("there are " + emptyCount + " empty cells and " + collideCount + " collisions in the hash table");
		
	}
	
	
	
	
	
	
	//----------------------------------------------------------------------------------------------------//
	
	/**
	 * class that creates a double ended singly-linked list, checks if it is empty of collided, inserts to the end, deletes
	 * user define country, and searches for user defined country.
	 * @author jessicajackson
	 * @version 4Dec22
	 */
	public class LinkList {
		public Node first;
		public Node last;
		
		/**
		 * constructor for double ended list that defines a first and a last node.
		 */
		public LinkList() {
			first = null;
			last = null;
		}
		
		/**
		 * checks to see if the list is empty or not
		 * @return true if first node is null.
		 */
		public boolean isEmpty() {
			return (first == null);
		}
		
		/**
		 * inserts defined country name, pop, and cases to the end of the linked list. 
		 * @param country name
		 * @param population population
		 * @param cases cases
		 */
		public void insert(String country, long population, long cases) {
			Node n = new Node(country, population, cases);
			
			if( isEmpty() ){
				first = n;
			}
			else {
				last.nextNode = n;
			}
				last = n;
		}
		
		/**
		 * prints the linked list from first to last node
		 */
		public void print() {
			Node current = first; 
			while(current != null) 
			{
				current.printNode(); 
				current = current.nextNode; 
				if(current != null) {
					System.out.print("    ");
					
				}
			}
		
	}
		
		/**
		 * find the user defined country and prints the name, index, and caserate if found. says "not a country" if not found
		 * @param key user defined country name
		 * @return returns the current node if found or not.
		 */
		public Node find(String key) {
			Node curr = first;
			int hashval = hashFunc(key);
			int hash = hashFunc(curr.name);
			while(curr != null && hash <= hashval) {
				if(curr.name.compareTo(key) == 0) {
					double caserate = (double)curr.cases/curr.population*100000;
					System.out.printf("%s is found at index %d with a caserate of %.3f\n", curr.name, hashval, caserate);
					return curr;
				}
				curr = curr.nextNode;
				
			}
			
			return curr;
			
		}
		
		/**
		 * deleted a given node from the linked list. checks to see if country is in list before deletion.
		 * @param country name of country
		 */
		public void delete(String country) {
			Node temp = null;
			Node curr = first;
			
			while(curr != null && curr.name.compareTo(country) != 0) {
				temp = curr;
				curr = curr.nextNode;
				
				}
			if(curr == null) {
				System.out.println(country + " not a country");
				return;
			}
				if(temp == null) {
					first = first.nextNode;
				}
				else {
					temp.nextNode = curr.nextNode;
				}
				System.out.println(country + " deleted");
		}
		
		/**
		 * goes through list and counts how many nodes are in the list. 
		 * @return true if list contains more than 1 node.
		 */
		public boolean isCollided() {
			Node curr = first;
			//Node temp = null;
			int nodeCount = 0;
			while (curr != null) {
				curr = curr.nextNode;
				
					nodeCount++;
				
			}
			return(nodeCount >= 2);
		}
	}
	
	
	
	
	
	
//----------------------------------------------------------------------------------------------------------//
	
	/**
	 * node class provided by professor, untouched. creates node for linked list with name, pop, and case data.
	 * @author Prof. Liu
	 *
	 */
	private class Node { 
		String name; 
		long population; 
		long cases; 
		Node nextNode; 
		 
		/**
		 * constructor for node object. creates empty node
		 * @param name name of country
		 * @param population pop of country
		 * @param cases cases for country
		 */
		public Node(String name, long population, long cases) { 
			this.name = name; 
			this.population = population; 
			this.cases = cases; 
		   } 
		 
		/**
		 * prints the nodes name and caserate out and formats it correctly for output.
		 */
		public void printNode() { 
		   System.out.printf("%-30s %-20.3f\n", name,(double)cases/population*100000); 
		   } 
		}
	

	
	
}
