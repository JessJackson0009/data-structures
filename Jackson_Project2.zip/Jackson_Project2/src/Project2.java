import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 * class that houses the main method and menu method of which takes in user input, fills a stack and a priority queue, prints a menu and asks the user to pick
 * options from that menu.
 * @author jessicajackson
 * @version 30sep2022
 */
public class Project2 {
/**
 * creats an empty stack and queue, reads in csv file, loads file into stack and queue, prints menu for user to interact with
 * @param args
 */
	public static void main(String[] args) {
		
		Stack s1 = new Stack(145);
		PriorityQ q1 = new PriorityQ(145);
		
		Scanner fileName = new Scanner(System.in);
		System.out.println("Enter File Name");
		String file = fileName.nextLine();
		
		
		Scanner input = null;
		try {
			input = new Scanner(new File(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		input.useDelimiter(",|\n");
		input.nextLine();
		int i = 0;
		while(input.hasNext()) {
			String n = input.next();
			String c = input.next();
			double p = input.nextDouble();
			double G = input.nextDouble();
			double ca = input.nextDouble();
			double d = input.nextDouble();
			double a = input.nextDouble();
			Country country = new Country(n, c, p, G, ca, d, a);
			s1.push(country);
			q1.insert(country);
			++i;
			}
		System.out.println(i + " countries have been read\n");
		Menu(s1,i,q1);
		fileName.close();
		input.close();
	}
/**
 * displays menu for user to interact with. takes user input and does desired tasks of: printing the stack, popping the stack, pushing a user created country to the stack,
 * printing the priority queue, removing a country from the front of the queue, inserting a country object by sorted cfr is acsending order. when 7 is hit the program
 * terminates, checks for proper input as well.
 * 
 * @param s1 stack created in main
 * @param i index of both stack and queue array
 * @param q1 queue created in main
 */
	static void Menu(Stack s1, int i,PriorityQ q1) {
		System.out.print("1. Print Stack\n2. Pop a country from the stack\n3. push a country object onto the stack\n4. Print priority queue\n"
				+ "5. remove a country object from the priority queue\n"
				+ "6. insert a country object from the priority queue\n7. Quit\n\n Enter Choice:");
		Scanner scn = new Scanner(System.in);
		int in = scn.nextInt();
		while(in != 7) {
			if(in > 7 || in < 1) {
				System.out.println("invalid try again");
				}
			
			if(in == 1) {
			
				s1.PrintStack(s1, i);
				
			}
			if(in == 2) {
				if(!s1.isEmpty()) {
				s1.pop();
				System.out.println("one counry was popped from the stack");
				System.out.println();
				}
				else {
					System.out.println("you cannot remove any more countries! the stack is empty!");
					System.out.println();
				}
			}
			if(in == 3) {
				if(!s1.isFull()) {
				Scanner user = new Scanner(System.in);
				System.out.println("enter name:");
				String n = user.next();
				System.out.println("enter capitol:");
				String c = user.next();
				System.out.println("enter population:");
				double p = user.nextDouble();
				System.out.println("enter GDP:");
				double G = user.nextDouble();
				System.out.println("enter cases:");
				double ca = user.nextDouble();
				System.out.println("enter deaths:");
				double d = user.nextDouble();
				System.out.println("enter area:");
				double a = user.nextDouble();
				//user.close();
				Country country = new Country(n,c,p,G,ca,d,a);
				s1.push(country);
				//user.close();
				}
				else {
					System.out.println("you cannot add a country! the stack is full!");
					System.out.println();
				}
			
			}
			if(in == 4) {
				q1.printQueue(q1, i);
			}
			if(in == 5) {
				if(!q1.isEmpty()) {
				q1.remove();
				System.out.println("a country has been removed from the queue");
				System.out.println();
				}
				else {
					System.out.println("cannot remove anymore countries! the queue is empty!");
					System.out.println();
				}
			}
			if(in == 6) {
				if(!q1.isFull()) {
				Scanner user = new Scanner(System.in);
				System.out.println("enter name:");
				String n = user.next();
				System.out.println("enter capitol:");
				String c = user.next();
				System.out.println("enter population:");
				double p = user.nextDouble();
				System.out.println("enter GDP:");
				double G = user.nextDouble();
				System.out.println("enter cases:");
				double ca = user.nextDouble();
				System.out.println("enter deaths:");
				double d = user.nextDouble();
				System.out.println("enter area:");
				double a = user.nextDouble();
				Country country = new Country(n,c,p,G,ca,d,a);
				q1.insert(country);
				//user.close();
				}
				else {
					System.out.println("cannot add another country the queue is full!");
					System.out.println();
				}
			}
			System.out.print("1. Print Stack\n2. Pop a country from the stack\n3. push a country object onto the stack\n4. Print priority queue\n"
					+ "5. remove a country object from the priority queue\n"
					+ "6. insert a country object from the priority queue\n7. Quit\n\n Enter Choice:");
			in = scn.nextInt();
			
		}
	scn.close();
	
	}

}
