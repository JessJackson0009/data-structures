/**
 * a class used to create a priorty queue sorted by a countries CFR in ascending order. it is used to check if the queue is empty or full, insert new coutries to the ques
 * and remove countries from the queue.
 * @author jessicajackson
 * @version 30sep2022
 */
public class PriorityQ {
	private int size;
	private Country[] qArr;
	private int num;
	/**
	 * a constructor for a priority queue object, makes a queue array of country type with a defined size.
	 * @param s size of the queue aray
	 */
	public PriorityQ(int s) {
		size = s;
		qArr = new Country[size];
		num = 0;
	}
	/**
	 * checks to see if the queue is empty
	 * @return retuns true if the queue is empty
	 */
	public boolean isEmpty() {
		return(num ==0);
	}
	/**
	 * checks to see if the queue is full
	 * @return returns true if the queue is full
	 */
	public boolean isFull() {
		return (num == size);
	}
	/**
	 * method for inserting a user defined country, takes the queue and sorts it by cfr, the lower the cfr the higher the priorty. therefore, the priortity queue is in 
	 * acsending order by cfr. find where new country should be placed and inserts it in the queue.
	 * @param country takes the user defined county as a parameter.
	 */
	public void insert(Country country) {
		int i;
		if(num == 0) {
			qArr[num++] = country;
		}
		else {
			for(i = num -1;i >=0;i--) {
				if(country.getCFR().compareTo(qArr[i].getCFR()) > 0) {
					qArr[i+1] = qArr[i];
				}
				else {
					break;
				}
			}
			qArr[i+1] = country;
			num++;
		}
	}
	/**
	 * removes the highest priorty country. removed from the front of the queue.
	 * @return returns the queue array without the removed country
	 */
	public Country remove() {
		return qArr[--num];
	}
	/**
	 * prints the priory queue by name, capitol, GDPPC, CFR, case rate, death rate, and population density
	 * @param q1 priory quese that was created
	 * @param i index of quese array
	 */
	public void printQueue(PriorityQ q1, int i) {

		System.out.println("  Name                            Capitol          GDPPC         CFR           CaseRate     DeathRate     PopDensity" );
		System.out.println("----------------------------------------------------------------------------------------------------------------------");
		
		for(i = q1.num-1;i>=0;i--) {
			String n = qArr[i].getName();
			String c = qArr[i].getCap();
			double GDPPC = qArr[i].getGDPPC();
			double CFR = qArr[i].getCFR();
			double CaseRate = qArr[i].getCaseRate();
			double DeathRate = qArr[i].getDeathRate();
			double PopDens = qArr[i].getPopDens();
			System.out.printf("%-34s%-15s%-15.3f%-15.6f%-15.3f%-15.3f%-15.3f\n",n,c,GDPPC,CFR,CaseRate,DeathRate,PopDens);	
		}
		System.out.println();
	}
}
