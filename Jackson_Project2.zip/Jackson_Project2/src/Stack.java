/**
 * a class used to create a stack of country objects, push new objects onto the stack, remove objects from the stack, check is the stack is empty or full, and
 * to print the entire stack.
 * @author jessicajackson
 * @version 30sep2022
 */
public class Stack {
	private int size;
	private Country[] stackArr;
	private int top;
	/**
	 * constructor for a stack object, makes a stack array of country type.
	 * @param s size of the stack
	 */
	public Stack(int s) {
		size = s;
		stackArr = new Country[size];
		top = -1;
	}
	/**
	 * pushes a created country object onto the stack
	 * @param country country created from user
	 */
	public void push(Country country) {
		stackArr[++top] = country;
	}
	/**
	 * pops a country from the top of the stack
	 * @return returns the stack arr without the country that got popped
	 */
	public Country pop() {
		return stackArr[top--];
	}
	/**
	 * checks to see if the stack is empty
	 * @return returns true if stack is empty
	 */
	public boolean isEmpty() {
		return (top ==-1);
	}
	/**
	 * checks to see if stack is full
	 * @return returns true if stack is full
	 */
	public boolean isFull() {
		return (top == size -1);
	}
	/**
	 * prints the name, capitol, GDPPC, CFR, case rate, deatn rate, and population density of the entire stack
	 * @param stack stack created by the user
	 * @param i index of the stack array that is being parsed through
	 */
	public void PrintStack(Stack stack,int i){
		
		System.out.println("  Name                            Capitol          GDPPC         CFR           CaseRate     DeathRate     PopDensity" );
		System.out.println("----------------------------------------------------------------------------------------------------------------------");
		
		for(i = stack.top;i>=0;i--) {
			String n = stackArr[i].getName();
			String c = stackArr[i].getCap();
			double GDPPC = stackArr[i].getGDPPC();
			double CFR = stackArr[i].getCFR();
			double CaseRate = stackArr[i].getCaseRate();
			double DeathRate = stackArr[i].getDeathRate();
			double PopDens = stackArr[i].getPopDens();
			System.out.printf("%-34s%-15s%-15.3f%-15.6f%-15.3f%-15.3f%-15.3f\n",n,c,GDPPC,CFR,CaseRate,DeathRate,PopDens);
		}
		System.out.println();
	}
}
