/**
 * a class used to set and get values for a country object as well as calculate values used in the main program.
 * 
 * @author jessicajackson
 * @version 30Sep2022
 */
public class Country {
	private String name;
	private String capitol;
	private double population;
	private double GDP;
	private double cases;
	private double deaths;
	private double area;
/**
 * 	sets the name of the country object
 * @param n allows for a string to inputed to set name of country
 */
public void setName(String n) {
	this.name = n;
}
/**
 * returns the name of country
 * @return returns name of country object
 */
public String getName() {
	return this.name;
}
/**
 * sets capitol of country
 * @param c capitol of country object
 */
public void setCap(String c) {
	this.capitol = c;
}
/**
 * gets capitol of country object
 * @return returns capitol of country
 */
public String getCap() {
	return this.capitol;
}
/**
 * set country population
 * @param p population of country
 */
public void setPop(double p) {
	this.population = p;
}
/**
 * get population of country object
 * @return returns population of country
 */
public double getPop() {
	return this.population;
}
/**
 * sets country GDP
 * @param G GDP of country
 */
public void setGDP(double G) {
	this.GDP = G;
}
/**
 * gets GDP of country object
 * @return returns country GDP
 */
public double getGDP() {
	return this.GDP;
}
/**
 * sets country covid cases
 * @param ca cases
 */
public void setCases(double ca) {
	this.cases = ca;
}
/**
 * gets countries number of covid cases
 * @return countries covid cases
 */
public double getCases() {
	return this.cases;
}
/**
 * sets countries deaths
 * @param d deaths of country
 */
public void setDeaths(double d) {
	this.deaths = d;
}
/**
 * gets countries death count
 * @return countries death count
 */
public double getDeaths() {
	return this.deaths;
}
/**
 * sets countries area
 * @param a countries area
 */
public void setArea(double a) {
	this.area = a;
}
/**
 * gets the countries area
 * @return country area
 */
public double getArea() {
	return this.area;
}
/**
 * constructor for country object. fills all areas of the countries statistic into one object
 * @param n name
 * @param c capitol
 * @param p population
 * @param G GDP
 * @param ca covid cases
 * @param d covid deaths
 * @param a area
 */
public Country(String n, String c, double p, double G, double ca, double d, double a) {
	this.name = n;
	this.capitol = c;
	this.population = p;
	this.GDP = G;
	this.cases = ca;
	this.deaths = d;
	this.area = a;
}
/**
 * prints country objects attributes.
 */
public String toString() {
	return this.name + ", " + this.capitol + ", " + this.population + ", " + this.GDP + ", " + this.cases + ", "+ this.deaths + ", " 
			+ this.area;
 }
/**
 * calulates countries CFR values 
 * @return CFR value for country
 */
public Double getCFR() {
	return this.deaths/this.cases;
}
/**
 * calculates GDPPC values for country
 * @return GDPPC values
 */
public double getGDPPC() {
	// TODO Auto-generated method stub
	return this.GDP/this.population;
}
/**
 * calculates country case rate
 * @return case rate value for country
 */
public double getCaseRate() {
	return (this.cases/this.population) * 100000;
}
/**
 * calculates country death rate due to covid
 * @return death rate for country
 */
public double getDeathRate() {
	return (this.deaths/this.population) * 100000;
}
/**
 * calculates country population density
 * @return pop density for country
 */
public double getPopDens() {
	return this.population/this.area;
}
}
