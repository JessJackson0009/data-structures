import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * class to hold the main method and present user with options and take in input. 
 * @author jessicajackson
 *
 */
public class Project4 {
	/**
	 * main method used to read in file. insert to tree and priority queues and create country objects.
	 * @param args
	 */
	public static void main(String[] args) {
		
	    BinarySearchTree tree = new BinarySearchTree();
	    PriorityQ q1 = new PriorityQ(145);
	    PriorityQ q2 = new PriorityQ(145);
	    
		Scanner fileName = new Scanner(System.in);
		System.out.println("Enter File Name");
		String file = fileName.nextLine();
		//fileName.close();
		
		
		Scanner input = null;
		try {
			input = new Scanner(new File(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(1);
		}
		input.useDelimiter(",|\n");
		input.nextLine();
		int i = 0;
		while(input.hasNext()) {
			String n = input.next();
			String c = input.next();
			double p = input.nextDouble();
			double G = input.nextDouble();
			double ca = input.nextDouble();
			double d = input.nextDouble();
			String a = input.next();
			double a1 = Double.parseDouble(a);
			Country country = new Country(n, c, p, G, ca, d, a1);
			tree.insert(country.getName(), country.getGDPPC());
			q1.insertTop(country);
			q2.insertBot(country);
			i++;
	}
		System.out.println("");
		System.out.println(i + " have been loaded into the Binary Search Tree\n");
		Menu(tree, q1, q2);
	}
		/**
		 * used to create menu and move through menu options until prompted to quit program
		 * @param tree the tree made in the main method.
		 */
		static void Menu(BinarySearchTree tree, PriorityQ q1, PriorityQ q2) throws InputMismatchException {
			
			int in;
			Scanner scn = new Scanner(System.in);
			System.out.print("1. Print tree inorder\n"
					+ "2. Print tree preorder\n3. Print tree postorder\n4. Insert a country with name and GDP per capita\n5. Delete a country for a given name\n"
					+ "6. Search and print a country and itspath for a given name\n7. Print bottom countries regarding GDPPC\n"
					+ "8. Print top countries regarding GDPPC\n9. Exit program\n\n Enter Choice:");
			
			in = scn.nextInt();
			while(in != 9) {
				if(in > 9 || in < 1 || Character.isDigit(in) == true) {
					System.out.println("\n\ninvalid try again\n\n");
					}
				if(in == 1) {
					System.out.println("\nName                                GDPPC");
					System.out.println("-----------------------------------------");
					tree.printInorder(tree.root);
					System.out.println("");
				}
				if(in == 2) {
					System.out.println("\nName                                GDPPC");
					System.out.println("-----------------------------------------");
					tree.printPreorder(tree.root);
					System.out.println("");
				}
				if(in == 3) {
					System.out.println("\nName                                GDPPC");
					System.out.println("-----------------------------------------");
					tree.printPostorder(tree.root);
					System.out.println("");
				}
				if(in == 4) {
					String input;
					double Gdppc;
					Scanner temp = new Scanner(System.in);
					Scanner temp2 = new Scanner(System.in);
					System.out.print("Country name to insert:");
					input = temp.next();
					System.out.print("countries GDPPC to insert:");
					Gdppc = temp2.nextDouble();
					tree.insert(input, Gdppc);
					System.out.println("");
					System.out.println(input + " with GDPPC of "+ Gdppc +" have been inserted to the tree\n");
					
				}
				if(in == 5) {
					String delete;
					Scanner del = new Scanner(System.in);
					System.out.print("choose a country to delete:");
					delete = del.next();
					System.out.println("");
					tree.delete(delete);
					
				}
				if(in == 6) {
					String search;
					Scanner s = new Scanner(System.in);
					System.out.print("country to find:");
					search = s.next();
					System.out.println("");
					tree.find(search);
				}
				if(in == 7) {
					int c;
					Scanner cS = new Scanner(System.in);
					System.out.print("how many countries to print:");
					c = cS.nextInt();
					System.out.println("\nBottom " + c + " Countries are:");
					System.out.println("\nName                                GDPPC");
					System.out.println("-----------------------------------------");
					if(c > 145) {
						q1.print(q1);
						System.out.println("\nThere are only 145 Countries\n");
					}
					else {
					tree.printBottomCountries(c, q2);
					}
				}
				if(in == 8) {
					int c;
					Scanner cS = new Scanner(System.in);
					System.out.print("how many countries to print:");
					c = cS.nextInt();
					System.out.println("\nTop " + c + " Countries are:");
					System.out.println("\nName                                GDPPC");
					System.out.println("-----------------------------------------");
					if(c >145) {
						q2.print(q2);
						System.out.println("\nThere are only 145 Countries\n");
					}
					else {
					tree.printTopCountries(c, q1);
					}
				}
				System.out.print("1. Print tree inorder\n"
						+ "2. Print tree preorder\n3. Print tree postorder\n4. Insert a country with name and GDP per capita\n5. Delete a country for a given name\n"
						+ "6. Search and print a country and itspath for a given name\n7. Print bottom countries regarding GDPPC\n"
						+ "8. Print top countries regarding GDPPC\n9. Exit program\n\n Enter Choice:");
				in = scn.nextInt();
				}
			}
			

}
