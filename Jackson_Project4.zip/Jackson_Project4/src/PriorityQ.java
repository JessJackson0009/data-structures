/**
 * a class used to create a priorty queue sorted by a countries GDPPC in ascending/desending order. it is used to insert new coutries to the ques
 * 
 * @author jessicajackson
 * @version 15Nov2022
 */
public class PriorityQ {
	private int size;
	private Country[] qArr;
	private int num;
	/**
	 * a constructor for a priority queue object, makes a queue array of country type with a defined size.
	 * @param s size of the queue aray
	 */
	public PriorityQ(int s) {
		size = s;
		qArr = new Country[size];
		num = 0;
	}
	/**
	 * inserts country objects based on GDPPC, this method inserts where lower GDPPC has priorty. 
	 * this method creates a queue of GDPPC from lowest to highest
	 * @param country country object
	 */
	public void insertTop(Country country) {
		int i;
		if(num == 0) {
			qArr[num++] = country;
		}
		else {
			for(i = num -1;i >=0;i--) {
				if(country.getGDPPC() > qArr[i].getGDPPC()) {
					qArr[i+1] = qArr[i];
				}
				else {
					break;
				}
			}
			qArr[i+1] = country;
			num++;
		}
	}
	/**
	 * inserts country objects based on GDPPC, this method inserts where higher GDPPC has priorty. 
	 * this method creates a queue of GDPPC from highest to lowest
	 * @param country country object
	 */
	public void insertBot(Country country) {
		int i;
		if(num == 0) {
			qArr[num++] = country;
		}
		else {
			for(i = num -1;i >=0;i--) {
				if(country.getGDPPC() < qArr[i].getGDPPC()) {
					qArr[i+1] = qArr[i];
				}
				else {
					break;
				}
			}
			qArr[i+1] = country;
			num++;
		}
	}
	/**
	 * prints the queue based on a priorty of highest GDPPC. using a user defined size to print. 
	 * @param q1 the queue
	 * @param c the user defined size to print
	 */
	public void printQueueTop(PriorityQ q1, int c) {
		
		for(int i = 0;i <= c-1;i++) {
			String Name = qArr[i].getName();

			double GDPPC = qArr[i].getGDPPC();
			System.out.printf("%-34s%-15.3f\n",Name,GDPPC);	
		}
		System.out.println();
	}
	/**
	 * prints the queue based on a priorty of lowest GDPPC. using a user defined size to print. 
	 * @param q1 the queue
	 * @param c the user defined size to print
	 */
	public void printQueueBot(PriorityQ q1, int c) {
		
		for(int i = 0;i <= c-1;i++) {
			String Name = qArr[i].getName();

			double GDPPC = qArr[i].getGDPPC();
			System.out.printf("%-34s%-15.3f\n",Name,GDPPC);	
		}
		System.out.println();
	}
	/**
	 * prints the whole queue regaurdless of defined size. from highest to lowest priority.
	 * @param q1 the queue
	 */
	public void print(PriorityQ q1) {
		for(int i = q1.num-1;i>=0;i--) {
			String Name = qArr[i].getName();

			double GDPPC = qArr[i].getGDPPC();
			System.out.printf("%-34s%-15.3f\n",Name,GDPPC);
		}
	}
}
