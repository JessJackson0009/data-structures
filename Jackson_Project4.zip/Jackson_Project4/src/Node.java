/**
 * a class to define what data is held in each nde of the binary search tree.
 * @author jessicajackson
 * @version 15Nov2022
 */
public class Node {
	public Country data;
	public String Name;
	public double GDPPC;
	Node leftChild;
	Node rightChild;
	
	/**
	 * a method to display the name and GDPPC of each node in the search tree.
	 */
	public void Display() {
		
		System.out.printf("%-34s%-15.3f\n",Name,GDPPC);
	}
}
