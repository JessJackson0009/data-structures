/**
 * a class to create a binary search tree, print its contents, insert into it, delete from it, and search through it.
 * @author jessicajackson
 * @version 15Nov2022
 */
public class BinarySearchTree {
	public Node root;
	public PriorityQ q1;
	
	/**
	 * constructor for the Binary search tree
	 */
	public BinarySearchTree() {
		root = null;
	}
	/**
	 * a method to insert into the correct location of the binary search tree.
	 * @param name name of country
	 * @param GDPPC of country
	 */
	public void insert(String name, double GDPPC) {
		Node n = new Node();
		n.Name = name;
		n.GDPPC = GDPPC;
		if(root == null) {
			root = n;
		}
		else {
			Node curr = root;
			Node p;
			while(true) {
				p = curr;
				if(name.compareTo(curr.Name) < 0) {
					curr = curr.leftChild;
					if(curr == null) {
						p.leftChild = n;
						return;
					}
				}
				else {
					curr = curr.rightChild;
					if(curr == null) {
						p.rightChild = n;
						return;
					}
				}
			}
		}
	}
	/**
	 * method to find a user specified country in the binary search tree.
	 * @param key (what is being found)
	 * @return returns -1 if not found, and the countries GDPPC if found.
	 */
	public double find(String key) {
		Node curr = root;
		while(curr != null && !curr.Name.equals(key)) {
			System.out.print(curr.Name + " -> ");
			if(key.compareTo(curr.Name)<0) {
				curr = curr.leftChild;
			}
			else {
				curr = curr.rightChild;
			}
			if(curr == null) {
				System.out.println(" NOT FOUND TRY AGAIN\n");
				return -1;
			}
			
		}
		System.out.print(curr.Name + " which has a GDPPC of ");
		double g = curr.GDPPC;
		System.out.printf("%.3f\n", g);
		System.out.println("");
		return curr.GDPPC;
	}
	/**
	 * a method to delete a user specified country, taking into account if said node has children or not.
	 * @param key (what to delete)
	 */
	public void delete(String key) {
		Node curr = root;
		Node par = root;
		boolean isleftchild = true;
		
		while(!curr.Name.equals(key))
		{
			par = curr;
			if(key.compareTo(curr.Name)< 0) {
				isleftchild = true;
				curr = curr.leftChild;
			}
			else {
				isleftchild = false;
				curr = curr.rightChild;
			}
			if(curr == null) {
				System.out.println("Tree is empty/ or country not found. nothing to delete\n");
				return;
			}
		
		}
		//if no children
		if(curr.leftChild == null && curr.rightChild == null) {
			if(curr == root) {
				root = null;
			}
			else if(isleftchild) {
				par.leftChild = null;
			}
			else {
				par.rightChild = null;
			}
		}
		//has no right child
		else if(curr.rightChild == null) {
			if(curr == root) {
				root = curr.leftChild;
			}
			else if(isleftchild) {
				par.leftChild = curr.leftChild;
			}
			else {
				par.rightChild = curr.leftChild;
			}
		}
		//has no left child
		else if(curr.leftChild == null) {
			if(curr == root) {
				root = curr.rightChild;
			}
			else if(isleftchild) {
				par.leftChild = curr.rightChild;
			}
			else {
				par.rightChild = curr.rightChild;
			}
		}
		//has 2 children
		else {
			Node succ = getSucc(curr);
			if(curr == root) {
				root = succ;
			}
			else if(isleftchild) {
				par.leftChild = succ;
			}
			else {
				par.rightChild = succ;
			}
			succ.leftChild = curr.leftChild;
		}
		System.out.println("deleted successfully\n");
		
	}
	/**
	 * to find the successor node if there was a node deleted that has children
	 * @param delNode node to be deleted
	 * @return resturns the successor node
	 */
	private Node getSucc(Node delNode) {
		Node succPar = delNode;
		Node Succ = delNode;
		Node curr = delNode.rightChild;
		while(curr != null) {
			succPar = Succ;
			Succ = curr;
			curr = curr.leftChild;
		}
		if(Succ != delNode.rightChild) {
			succPar.leftChild = Succ.rightChild;
			Succ.rightChild = delNode.rightChild;
		}
		return Succ;
	}
	/**
	 * print tree in order. left, parent, right
	 * @param root root of tree as is being read
	 */
	public void printInorder(Node root) {
		if(root != null) {
			printInorder(root.leftChild);
			root.Display();
			printInorder(root.rightChild);
		}
	}
	/**
	 * prints tree in pre order. parent, left right
	 * @param root root of tree as is being read
	 */
	public void printPreorder(Node root) {
		if(root!=null) {
			root.Display();
			printPreorder(root.leftChild);
			printPreorder(root.rightChild);
		}
	}
	/**
	 * prints tree in post order. left right parent.
	 * @param root root of tree as is being read
	 */
	public void printPostorder(Node root) {
		if(root!= null) {
			printPostorder(root.leftChild);
			printPostorder(root.rightChild);
			root.Display();
		}
	}
	/**
	 * prints bottom countries based on user input
	 * @param c user input
	 */
	public void printBottomCountries(int c, PriorityQ q1) {
		q1.printQueueBot(q1, c);
	}
	/**
	 * prints top countries based on user input
	 * @param c user input
	 */
	public void printTopCountries(int c, PriorityQ q1) {
		
		q1.printQueueTop(q1, c);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
