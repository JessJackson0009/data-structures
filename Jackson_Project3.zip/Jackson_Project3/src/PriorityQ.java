/**
 * Priorty queue class used to display the countries in the given priorty based on deathrate. from lowest to highest deathrate.
 * @author jessicajackson
 * @version 28Oct2022
 */
public class PriorityQ {
	private List listQ;
	/**
	 * constructor for a priority queue. creates a linked list to traverse through.
	 */
	public PriorityQ(){
		listQ = new List();
	}
	/**
	 * checks to see if the queue is empty. calls the is empty methos in the list class.
	 * @return true if empty. false if not empty
	 */
	public boolean isEmpty() {
		return listQ.isEmpty();
	}
	/**
	 * removes countries from the queue based on priority. removes the highest priority first. calls the delete method from the list class
	 * @return countries that have been removed
	 */
	public Country remove() {
		return listQ.delete();
	}
	/**
	 * inserts countries to the queue based on priority. calls the InsertQ method in the list class. inserts from lowest to hight DR.
	 * @param c country objects to be inserted
	 */
	public void insert(Country c) {
		listQ.InsertQ(c);
	}
	/**
	 * prints the priority queue in order of lowest death rate to highest deathrate
	 */
	public void printPriorityQ() {
		System.out.println("Name                              Capitol        GDPPC          CFR            CaseRate       DeathRate      PopDensity" );
		System.out.println("-----------------------------------------------------------------------------------------------------------------------");
		System.out.println("(all countries in FAIR, GOOD, and VGOOD in the priority queue from highest priority to lowest");
		
		listQ.Print(listQ.first);
	}
	/**
	 * deletes a specified user interval. deletes greater than a and less than b. removes user specified countries from queue.
	 * @param a minimum value
	 * @param b maximum value
	 */
	public void intervalDelete(double a, double b) {
		listQ.intervalDelete(a, b);
	}
}
