/**
 * class to create the nodes that are used to create a list as well as displays that nodes data.
 * @author jessicajackson
 * @version 28Oct2022
 */
public class Node {
	public Country data;
	public Node next;
	public Node previous;
	/**
	 * constructor to create new nodes to add to a list.
	 * @param c country objects being loaded into nodes.
	 */
	public Node(Country c) {
		data = c;
	}
	/**
	 * displays the nodes data and creates the table seen in the main output of the program.
	 */
	public void display(){
		String n = data.getName();
		String c = data.getCap();
		double GDPPC = data.getGDPPC();
		double CFR = data.getCFR();
		double CaseRate = data.getCaseRate();
		double DeathRate = data.getDeathRate();
		double PopDens = data.getPopDens();
		
		System.out.printf("%-34s%-15s%-15.3f%-15.6f%-15.3f%-15.3f%-15.3f\n",n,c,GDPPC,CFR,CaseRate,DeathRate,PopDens);
	}
}
