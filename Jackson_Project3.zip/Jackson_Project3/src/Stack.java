/**
 * stack class used to create a stack of objects and manipulate those objects.
 * @author jessicajackson
 * @version 28Oct2022
 */
public class Stack {
	private List list;
	/**
	 * constructor for a stack which creates a linked list to traverse and manipulate the stack. 
	 */
	public Stack() {
		list = new List();
	}
	/**
	 * a method used to push the country objects to the stack.
	 * @param c countries
	 */
	public void push(Country c) {
		list.insert(c);
	}
	/**
	 * removes countries from the top of the stack one at a time.
	 * @return returns deleted objects
	 */
	public Country pop() {
		return list.delete();
	}
	/**
	 * checks to see if the stack is empty
	 * @return true if empty. false if not empty
	 */
	public boolean isEmpty() {
		return (list.isEmpty());
	}
	 /**
 	 * prints the stack in a recursive manner calls the print method from the list class
 	 */
	public void printStack() {
		System.out.println("Name                              Capitol        GDPPC          CFR            CaseRate       DeathRate      PopDensity" );
		System.out.println("-----------------------------------------------------------------------------------------------------------------------");
		System.out.println("(all countries in FAIR, GOOD, and VGOOD in the stack from top to bottom");
		list.Print(list.first);
	}
}
	

