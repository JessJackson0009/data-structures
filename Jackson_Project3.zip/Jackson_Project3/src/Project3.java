import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * class that brings holds the main method, creates a stack and priority queue. reads the file in and creates the country objects
 * @author jessicajackson
 * @version 28Oct2022
 */
public class Project3 {
		/**
		 * main method used to create a stack and a priority queue. reads the csv file in and creates country objects from it input. pushes those objects to the stack. then prints the stack.
		 * then pops the countries from the stack one by one and inserts those into the queue. prints a menu for the user to selct options from until prompted to quit the program.
		 * @param args
		 */
		public static void main(String[] args) {
			
			Stack s1 = new Stack();
			PriorityQ q1 = new PriorityQ();
			
			
			Scanner fileName = new Scanner(System.in);
			System.out.println("Enter File Name");
			String file = fileName.nextLine();
			//fileName.close();
			
			
			Scanner input = null;
			try {
				input = new Scanner(new File(file));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				System.exit(1);
			}
			input.useDelimiter(",|\n");
			input.nextLine();
			int i = 0;
			while(input.hasNext()) {
				String n = input.next();
				String c = input.next();
				double p = input.nextDouble();
				double G = input.nextDouble();
				double ca = input.nextDouble();
				double d = input.nextDouble();
				String a = input.next();
				double a1 = Double.parseDouble(a);
				Country country = new Country(n, c, p, G, ca, d, a1);
				if(country.getDeathRate() >= 20 && country.getDeathRate() < 350) {
					s1.push(country); 
					i++;
					
				}
				}
			
			System.out.println(i);
			s1.printStack();
			System.out.println("\n\n");
			
			while(!s1.isEmpty()) {
				q1.insert(s1.pop());
			}
			
			q1.printPriorityQ();
			System.out.println("\n\n");
			Menu(q1);
			
			
		}
		/**
		 * method used to create a menu and display it to the user until specified to stop the program
		 * @param q1 take the priority queue in an a parameter to call its methods. 
		 */
		static void Menu(PriorityQ q1) {
			double a = 0;
			double b = 0;
			int in = 0;
			Scanner scn = new Scanner(System.in);
			System.out.print("1. Enter a DR interval for deletions on priority queue\n"
					+ "2. Print the priority queue\n3. Exit program\n\n Enter Choice:");
			
			in = scn.nextInt();
			while(in != 3) {
				if(in > 3 || in < 1) {
					System.out.println("\n\ninvalid try again\n\n");
					}
				if(in ==1) {
					System.out.println("Enter interval for deletion like: x,y. x must be less than y");
					System.out.println("Enter X: ");
					a = scn.nextDouble();
					System.out.println("Enter Y: ");
					b = scn.nextDouble();
					if(a>b) {
						System.out.println("invalid x must be less than y");
					}
					if(a<b) {
					q1.intervalDelete(a,b);
					}
				}
				if(in ==2) {
					q1.printPriorityQ();
				}
				System.out.print("1. Enter a DR interval for deletions on priority queue\n"
						+ "2. Print the priority queue\n3. Exit program\n\nEnter Choice:");
				in = scn.nextInt();
				}
			}
			
		
		}

		
