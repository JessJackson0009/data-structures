/**
 * A class that creates a linked list and implements methods to modify said list
 * @author jessicajackson
 * @version 28Oct2022
 */
public class List {
	public Node first;
	public Node last;
	private Node temp;
	/**
	 * constructor for a linked list creating the first and last node
	 */
	public List() {
		first = null;
		last = null;
	}
	/**
	 * checks to see if the list is empty
	 * @return true if empty
	 */
	public boolean isEmpty() {
		return (first == null);
	}
	/**
	 * insertion method used for inserting into a stack, it inserts unordered
	 * @param c country object that is loaded into the linked list one by one
	 */
	public void insert(Country c) {
		Node node = new Node(c);
		
		if(isEmpty()) {
			last = node;
		}
		else {
			first.previous = node;
		}
		node.next = first;
		first = node;
	}
	/**
	 * deletion method used for a stack that implements this list, deletes from the top of the stack
	 * @return
	 */
	public Country delete() {
		Node temp = first;
		first = first.next;
		return temp.data;
	}
	/**
	 * method to print the list out, uses recursion to print
	 * @param current current node used to move back and forth through the list
	 */
	public void Print(Node current) {
		if(current == null)
		{
			return;
		}
		current.display();
		Print(current.next);
	}	
	/**
	 * used to insert nodes from the list into a priorty queue. inserts nodes based on death rate with a lower deathrate having a higher priority
	 * @param c country data for the nodes to insert to the list.
	 */
	public void InsertQ(Country c) {
		Node node = new Node(c);
		Node temp = last;
		Node First = first;
		
		
		
		while(First != null && c.getDeathRate() > First.data.getDeathRate()) {
			temp = First;
			First = First.next;
		}
		if(temp == null) {
			node.next = first;
			first = node;
		}
		else {
			temp.next = node;
			node.next = First;
		}
	
}
	/**
	 * deletes values between a user specified min and max. currently still in progress as it does not actually delete yet.
	 * @param min min value to be deleted defined by the user
	 * @param max max value to be deleted defined by the user
	 * @return true if values were deleted and false if nothing was deleted.
	 */
public boolean intervalDelete(double min, double max) {
	Node curr = first;
	Node prev = first;
	
	
	if(!isEmpty()) {
	while(curr.data.getDeathRate() <= max) {
		curr = curr.next;
	}
	while(prev.data.getDeathRate() <= min) {
		prev = prev.next;
	}
	prev.next = curr.next;
	System.out.println("all countries between " + min + " and " + max + " have been deleted.");
	return true;
	}
	else {
		System.out.println("Queue is empty there is nothing to delete");
		return false;
	}
}
}
